# ARION Team OS - Team View Polish

팀원 화면 마감 패치입니다.

## 고친 내용

- 팀원 화면에서 빈 표 대신 안내 카드 표시
- 내 오늘 할 일 표를 한글 컬럼으로 표시
- 고급 편집은 접힌 메뉴로 숨김
- 왼쪽 사이드바에 팀 메신저 빠른 요청 폼 추가
- Streamlit toolbar를 minimal 설정으로 낮춤
- 앱 테마 light 고정

## 적용할 파일

GitHub에 아래 파일을 올리거나 교체하세요.

```text
app.py
requirements.txt
.streamlit/config.toml
```

## 적용 방법

1. `app.py` 교체
2. `requirements.txt` 교체
3. GitHub에 `.streamlit/config.toml` 추가

### .streamlit/config.toml 추가 방법

GitHub 저장소에서:

```text
Add file → Create new file
```

파일 이름에 아래처럼 입력:

```text
.streamlit/config.toml
```

내용:

```toml
[client]
toolbarMode = "minimal"

[theme]
base = "light"
```

그리고 Commit changes.

## 참고

오른쪽 위 Fork/GitHub 버튼은 Streamlit/공개 저장소 플랫폼 UI입니다.
완전히 감추려면 저장소를 private으로 운영하고 Streamlit 권한을 연결하는 쪽을 고려해야 합니다.
